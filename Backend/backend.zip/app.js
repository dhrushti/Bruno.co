const mysql = require("mysql");

const express = require("express");
const bodyParser = require("body-parser");

// const cors = require("cors");


// const saltRounds = 10;

const app = express();



app.use(bodyParser.urlencoded({ extended: true }));

// const io = new WebSocket.Server({ noServer: true });
// global.io = new WebSocket.Server({ noServer: true });
//static files rin public folder
app.use(express.static("public"));
// app.use(cors());

var db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "drushti",
    database: "bruno",
    
});

// var db = mysql.createConnection({
//     host: "localhost",
//     user: "root",
//     password: "@Akash2002",
//     database: "sculptica"
// });


var flag1 = 0;
  
db.connect(function(err) {
    if (err) {
        console.log(err);
    } else {
        console.log("Connected!");
        db.query(`SELECT table_name FROM information_schema.tables WHERE table_schema = 'bruno';`,(err,tables)=>{
            for(var i=0;i<tables.length;i++){
                if(tables[i].TABLE_NAME == "users") flag1 = 1;
            }

            if(!flag1){
                var sql = "CREATE TABLE users (name varchar(30),email varchar(50),passwd text);"
                db.query(sql,function(err,result){
                    if(err) console.log(err);
                    else{
                        console.log("users created");
                    }
                });
            }         
        });   
    }
});

app.get("/api",(req,res)=>{
    const s = "hello world"
    res.send(s)
})
app.get("/som",(req,res)=>{
    res.sendFile(__dirname + "/i.html")
})
app.post("/som",(req,res)=>{
    const a = req.body.abc;
    const b = req.body.def;
    res.send(a + b);
})
app.get("/abi",(req,res)=>{
    // res.sendFile("C:/Users/91636/Desktop/zarazara/my-app/public/index.html")
    const a = [1,3,5,7,9]; 
    res.send(a)
})
app.post("/abi",(req,res)=>{
    const a =req.body.username;
    const b=req.body.useremail;
    res.send(a+b);
})
app.listen(8000,function(){
    console.log('server started on port 8000');
})
